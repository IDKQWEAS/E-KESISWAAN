<?php
namespace App\Http\Controllers\Kepsek;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;

class DashboardController extends Controller
{
    public function index()
    {
        $token = Session::get('api_token');

        // Ambil audit logs untuk melihat aktivitas staf
        $resAudit = Http::withToken($token)->get(env('API_BASE_URL') . '/audit_logs');
        $resStat  = Http::withToken($token)->get(env('API_BASE_URL') . '/statistik');

        return view('kepsek.dashboard', [
            'logs'      => $resAudit->json('data'),
            'statistik' => $resStat->json('data'),
        ]);
    }
}
